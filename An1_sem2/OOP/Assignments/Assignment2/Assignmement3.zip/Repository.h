#pragma once

#ifndef REPOSITORY_H
#define REPOSITORY_H

typedef struct Medicine {

	char name[100], manufacturer[100];
	int id,quantity;

};

typedef struct Repository {

	struct Medicine medications[100];
	int index;

};

typedef struct Memory {

	struct Repository repositoryMemory[100];
	int index;
	int maxIndex; 

};


struct Memory memory;
struct Repository repository;


/*

Adds an element to the repository

*/

void add_medicine(id, name, manufacturer, quantity);


/*

Deletes the element with the matching ID

*/

void delete_medicine(id);


/*

Updates the element with the matching ID with the new values

*/

void update_medicine(id, newName, newManufacturer, newQuantity);


/*

Populates the repository 

*/

void start();


/*

Updates the memory with the current repository

*/

void update_memory();


/*

Undoes the last operation

*/

void undo();


/*

Redoes the last operation

*/

void redo();

#endif