#pragma once
#include <vector>
#include "Pet.h"

typedef Pet TElem;


class Repository
{
private:
	std::vector<TElem> dogs;

public:
	virtual void add_element(TElem element);
	virtual void update_element(TElem element);
	virtual void remove_element(std::string element);

	std::vector<TElem> get_elements();

	int lenght();
};

