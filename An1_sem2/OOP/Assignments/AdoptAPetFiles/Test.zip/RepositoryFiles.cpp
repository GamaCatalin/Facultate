#include "RepositoryFiles.h"

bool RepositoryFiles::add_element(TElem element)
{
	std::fstream file;

	if (this->fileLocation == "")
		return false;
	file.open(this->fileLocation);
	TElem tempElement;

	while (file >> tempElement) {
		if (tempElement.getName() == element.getName()) {
			file.close();
			return false;
		}
	}
	this->size++;
	file.close();
	file.open(this->fileLocation, std::ios::app);
	file << element;
	file.close();
	return true;
}

bool RepositoryFiles::remove_element(std::string elementName)
{
	std::fstream file;

	if (this->fileLocation == "")
		return false;
	file.open(this->fileLocation);
	TElem tempElement;
	std::vector<TElem> saveVector;
	bool elementExists=false;

	while (file >> tempElement) {
		if (tempElement.getName() != elementName) 
			saveVector.push_back(tempElement);
		if (tempElement.getName() == elementName)
			elementExists = true;
	}

	if (elementExists) {
		this->size--;
		file.open(this->fileLocation, std::ofstream::out);
		file.close();
		file.open(this->fileLocation, std::ios::out);
		for (auto& currentElement : saveVector) 
			file << currentElement;
		file.close();
		return true;
	}
	return false;
}

bool RepositoryFiles::update_element(TElem element)
{
	std::fstream file;

	if (this->fileLocation == "")
		return false;
	file.open(this->fileLocation);
	TElem tempElement;
	std::vector<TElem> saveVector;
	bool elementExists = false;

	while (file >> tempElement) {
		if (tempElement.getName() != element.getName())
			saveVector.push_back(tempElement);
		if (tempElement.getName() == element.getName()) {
			elementExists = true;
			saveVector.push_back(element);
		}
	}

	if (elementExists) {
		file.open(this->fileLocation, std::ofstream::out);
		file.close();
		file.open(this->fileLocation, std::ios::out);
		for (auto& currentElement : saveVector)
			file << currentElement;
		file.close();
		return true;
	}
	return false;
}

std::vector<TElem> RepositoryFiles::get_elements()
{
	std::fstream file;

	file.open(this->fileLocation);
	TElem tempElement;
	std::vector<TElem> saveVector;
	bool elementExists = false;

	while (file >> tempElement) {
		saveVector.push_back(tempElement);
	}
	return saveVector;
}

int RepositoryFiles::lenght()
{
	return this->size;
}

void RepositoryFiles::setFileLocation(std::string fileLocation)
{
	this->fileLocation = fileLocation;
}

TElem RepositoryFiles::getElementByIndex(int index)
{
	std::fstream file;
	TElem element;
	int counter=0;

	file.open(this->fileLocation);
	TElem tempElement;
	std::vector<TElem> saveVector;
	bool elementExists = false;

	while (file >> tempElement) {
		if (counter == index) {
			file.close();
			return tempElement;
		}
		counter++;
	}
}
