#pragma once
#include "Repository.h"
#include "RepositoryFiles.h"
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#ifndef SERVICE_H
#define SERVICE_H



class Service {
private:
	RepositoryFiles petShop;
	std::string runMode = "";
	std::vector<TElem> userAdoptionList;
	int userCurrentDogIndex=0;
public:
	
	void addElement(TElem element);
	void updateElement(TElem element);
	void removeElement(std::string name);

	int lenght();

	std::vector<TElem> getAll();
	std::vector<TElem> getAdoptionList();

	std::string getRunMode();
	void setRunMode(std::string runMode);


	virtual void saveDog(std::string name);
	TElem nextDog();

	bool changeFileLocation(std::string fileLocation);


};




#endif