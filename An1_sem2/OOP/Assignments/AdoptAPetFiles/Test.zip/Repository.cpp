#include "Repository.h"

void Repository::add_element(TElem element)
{
	this->dogs.push_back(element);
}

void Repository::update_element(TElem element)
{
	int counterIndex=0;
	for (auto current = this->dogs.begin(); current < this->dogs.end(); current++) {
		if (current->getName() == element.getName()) {
			*current = element;	
		}
		counterIndex++;
	}
}

void Repository::remove_element(std::string elementName)
{
	for (auto current = this->dogs.begin(); current < this->dogs.end(); current++)
		if (current->getName() == elementName)
		{
			this->dogs.erase(current);
		}

}

std::vector<TElem> Repository::get_elements()
{
	return this->dogs;
}

int Repository::lenght()
{
	return dogs.size();
}
