#include "Service.h"

void Service::addElement(TElem element)
{
	this->petShop.add_element(element);
}

void Service::updateElement(TElem element)
{
	this->petShop.update_element(element);

}

void Service::removeElement(std::string name)
{
	this->petShop.remove_element(name);
}

int Service::lenght()
{
	return this->petShop.lenght();
}

std::vector<TElem> Service::getAll()
{
	return petShop.get_elements();
}

std::vector<TElem> Service::getAdoptionList()
{
	return userAdoptionList;
}

std::string Service::getRunMode()
{
	return this->runMode;
}

void Service::setRunMode(std::string runMode)
{
	this->runMode = runMode;
}

void Service::saveDog(std::string name)
{
	std::vector<TElem> tempDogs = this->getAll();

	for (auto current = tempDogs.begin(); current < tempDogs.end(); current++)
		if (current->getName() == name)
		{
		this->userAdoptionList.push_back(*current);
		}
}

TElem Service::nextDog()
{
	TElem tempElement;
	std::vector<TElem> tempArray=this->petShop.get_elements();

	if (this->userCurrentDogIndex == this->petShop.lenght()-1) {
		tempElement = tempArray.at(this->userCurrentDogIndex);
		this->userCurrentDogIndex = 0;
	}
	else {
		tempElement = tempArray.at(this->userCurrentDogIndex);
		this->userCurrentDogIndex++;
	}
	return tempElement;
}

bool Service::changeFileLocation(std::string fileLocation)
{
	this->petShop.setFileLocation(fileLocation);
	return true;
}
